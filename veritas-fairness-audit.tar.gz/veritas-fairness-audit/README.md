# veritas-fairness-audit (AEGIS)

Lightweight fairness-audit actor. Returns a numeric `fairnessScore` and simple citations based on keyword heuristics.

Run:
```
apify run --input '{"caseNarrative":"Example mentioning race and gender..."}'
```

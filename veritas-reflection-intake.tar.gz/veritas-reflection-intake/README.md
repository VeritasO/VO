# veritas-reflection-intake (LYRA)

Lightweight actor that extracts grief and reflection themes from a case narrative.

Run locally
```
apify run --input '{"caseNarrative":"Two students fought..."}'
```

Replace with an LLM-backed implementation when desired.

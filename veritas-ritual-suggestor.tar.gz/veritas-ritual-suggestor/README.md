# veritas-ritual-suggestor (VESTA)

Suggests a restorative ritual and a concise repair plan informed by tier hints or narrative cues.

Run locally
```
apify run --input '{"caseNarrative":"Neighbors dispute over tree roots...","tier":"S2"}'
```
